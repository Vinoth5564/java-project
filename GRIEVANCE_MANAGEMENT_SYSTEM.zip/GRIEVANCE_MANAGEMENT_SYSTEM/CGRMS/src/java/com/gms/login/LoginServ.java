/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gms.login;

import com.gms.connection.ConnectionFactory;
import com.gms.utill.DBUtil;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.HashMap;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/loginserv")
public class LoginServ extends HttpServlet {

    private static String getusername = null; 
    private static String getpass = null;
    private static String getphoneno = null;
    private static String role = null;
	private static String loginstatus = null; 
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String username = null;
		String pass = null;
                       
		username = request.getParameter("username");
		pass = request.getParameter("password");
	
		System.out.println("user :"+username);
        System.out.println("pass :"+pass);
                       
                
                Connection chatconn = null;
                
                try{
		  	
		String qury = "select * from login_tbl  where empname ='"+username+"'";
	 	System.out.println("query --------VINOTH	------------------"+qury );
		chatconn = ConnectionFactory.getConnection();
		DBUtil dbUtil = new DBUtil(chatconn);
	 	ResultSet rst = dbUtil.executeQuery(qury);
	    
	    
	    while (rst.next()){
             request.getSession().setAttribute("login", "true");
	    	getusername = rst.getString("empname"); 
	    	getpass= rst.getString("pass");
	    	role = rst.getString("roll");
	    	}
	 	         System.out.println("user name------ :"+getusername);
                 System.out.println("user pass------ :"+getpass);
                 System.out.println("role--------- :"+role);
	}catch(Exception e){
	  //e.printStackTrace();
		System.out.println("Login servelt catche for finding  users and get mail");
	}
	finally{
		  if(chatconn !=null)
		try{
			chatconn.close();
			}catch(Exception e)
		{
		e.printStackTrace();	
		}
	}
		if(username.equals(getusername) && pass.equals(getpass) && role.equals("1"))
		{
			    
                    System.out.println("am from admin ");
                    response.sendRedirect("/auth/homeserlet");
                    HttpSession adminsession=request.getSession();  
				adminsession.setAttribute("username",getusername);
			  
			 
		}
		else if(username.equals(getusername) && pass.equals(getpass) && role.equals("2"))
		{
			System.out.println("am from supervisor");
            
            response.sendRedirect("/auth/superhomeserlet?empname="+username);
            HttpSession supersession=request.getSession();  
            supersession.setAttribute("username",getusername);
	   
	 
       }else if(username.equals(getusername) && pass.equals(getpass) && role.equals("3"))
		{
			System.out.println("am from personnel user");
           
           response.sendRedirect("/auth/persnolhomeserlet?empname="+username);
           HttpSession persession=request.getSession();  
           persession.setAttribute("username",getusername);
	  
	 
      }
		
		
		
		else
		{
			 //request.getRequestDispatcher("/EventManagement/logout?msg=error").forward(request, response);
                         response.sendRedirect("/loginpage?msg=error");
			 
		}
                        
    }
 

}
